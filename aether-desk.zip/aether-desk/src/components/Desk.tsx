import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  YAxis,
} from "recharts";
import {
  INTERVALS,
  UNIVERSE,
  clockEt,
  formatCompact,
  formatPct,
  formatPx,
  formatQty,
  formatUsd,
  getPair,
  signedClass,
  type Interval,
  type Side,
} from "../lib/market";
import { useDesk, useMark } from "../lib/store";
import { nid, roundToStep } from "../lib/utils";

export function Desk() {
  const book = useDesk((s) => s.book);
  const selected = useDesk((s) => s.selected);
  const interval = useDesk((s) => s.interval);
  const tickers = useDesk((s) => s.tickers);
  const sparks = useDesk((s) => s.sparks);
  const candles = useDesk((s) => s.candles);
  const bids = useDesk((s) => s.bids);
  const asks = useDesk((s) => s.asks);
  const trades = useDesk((s) => s.trades);
  const chat = useDesk((s) => s.chat);
  const tapeStatus = useDesk((s) => s.tapeStatus);
  const tapeError = useDesk((s) => s.tapeError);
  const agentBusy = useDesk((s) => s.agentBusy);
  const marketLoading = useDesk((s) => s.marketLoading);
  const select = useDesk((s) => s.select);
  const setInterval = useDesk((s) => s.setInterval);
  const refreshTape = useDesk((s) => s.refreshTape);
  const refreshMarket = useDesk((s) => s.refreshMarket);
  const submitOrder = useDesk((s) => s.submitOrder);
  const approveProposal = useDesk((s) => s.approveProposal);
  const dismissProposal = useDesk((s) => s.dismissProposal);
  const pushUser = useDesk((s) => s.pushUser);
  const pushAgent = useDesk((s) => s.pushAgent);
  const setAgentBusy = useDesk((s) => s.setAgentBusy);
  const resetBook = useDesk((s) => s.resetBook);

  const mark = useMark();
  const ticker = tickers[selected];
  const pair = getPair(selected);
  const dayPnl = mark - book.sessionStart;
  const dayPct = book.sessionStart ? (dayPnl / book.sessionStart) * 100 : 0;

  const [qty, setQty] = useState("");
  const [prompt, setPrompt] = useState("");
  const [now, setNow] = useState(() => clockEt());
  const [toast, setToast] = useState<string | null>(null);
  const [agentOpen, setAgentOpen] = useState(false);

  useEffect(() => {
    void refreshTape();
    void refreshMarket();
    const tapeTimer = window.setInterval(() => void refreshTape(), 5000);
    const mktTimer = window.setInterval(() => void refreshMarket(), 15000);
    const clockTimer = window.setInterval(() => setNow(clockEt()), 1000);
    return () => {
      window.clearInterval(tapeTimer);
      window.clearInterval(mktTimer);
      window.clearInterval(clockTimer);
    };
  }, [refreshTape, refreshMarket]);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 2800);
    return () => window.clearTimeout(t);
  }, [toast]);

  const chartData = useMemo(
    () => candles.map((c) => ({ t: c.t, c: c.c })),
    [candles],
  );
  const up =
    chartData.length >= 2
      ? chartData[chartData.length - 1].c >= chartData[0].c
      : (ticker?.changePct ?? 0) >= 0;
  const stroke = up ? "var(--color-up)" : "var(--color-down)";

  const maxBookQty = useMemo(() => {
    const all = [...bids, ...asks].map((l) => l.qty);
    return Math.max(1, ...all);
  }, [bids, asks]);

  function flash(msg: string) {
    setToast(msg);
  }

  function onTrade(side: Side) {
    const step = ticker?.stepSize || 0.0001;
    const n = roundToStep(Number(qty), step);
    if (!n) {
      flash("Enter a valid size.");
      return;
    }
    const res = submitOrder(side, n);
    if (!res.ok) {
      flash(res.error);
      return;
    }
    flash(`${side.toUpperCase()} ${formatQty(n)} ${pair.base} filled (paper).`);
    setQty("");
  }

  async function askAgent(message: string) {
    const text = message.trim();
    if (!text || agentBusy) return;
    pushUser(text);
    setPrompt("");
    setAgentBusy(true);

    const prices: Record<string, number> = {};
    for (const [k, v] of Object.entries(tickers)) prices[k] = v.last;
    const equityVal = mark;
    const positions = book.positions.map((p) => ({
      symbol: p.symbol,
      qty: p.qty,
      avgCost: p.avgCost,
      last: prices[p.symbol] ?? p.avgCost,
    }));
    const tape = Object.values(tickers).map((t) => ({
      symbol: t.symbol,
      last: t.last,
      changePct: t.changePct,
      bid: t.bid,
      ask: t.ask,
    }));
    const history = [...chat, { role: "user" as const, text }].slice(-6).map((c) => ({
      role: c.role,
      text: c.text,
    }));

    try {
      const res = await fetch("/api/agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          cash: book.cash,
          equity: equityVal,
          positions,
          tape,
          selected,
          history,
        }),
      });
      const data = (await res.json()) as {
        ok: boolean;
        error?: string;
        brief?: string;
        stance?: "bullish" | "bearish" | "neutral" | "mixed";
        proposals?: Array<{
          action: "buy" | "sell";
          symbol: string;
          qty: number;
          rationale: string;
          confidence: number;
        }>;
      };
      if (!data.ok) {
        pushAgent({ text: data.error || "Agent unavailable." });
      } else {
        pushAgent({
          text: data.brief || "No desk note.",
          stance: data.stance,
          proposals: (data.proposals ?? []).map((p) => ({
            id: nid(),
            action: p.action,
            symbol: p.symbol,
            qty: p.qty,
            rationale: p.rationale,
            confidence: p.confidence,
            status: "pending" as const,
          })),
        });
      }
    } catch {
      pushAgent({ text: "Could not reach the desk agent." });
    } finally {
      setAgentBusy(false);
    }
  }

  const agentPanel = (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <div>
          <p className="text-sm font-semibold tracking-tight">Agent</p>
          <p className="text-xs text-muted">Grok · paper proposals only</p>
        </div>
        <button
          type="button"
          className="rounded-sm border border-line px-2 py-1 text-xs text-muted hover:text-fg lg:hidden"
          onClick={() => setAgentOpen(false)}
        >
          Close
        </button>
      </div>

      <div className="desk-scroll flex-1 space-y-3 overflow-y-auto p-4">
        {chat.length === 0 && (
          <div className="space-y-3 text-sm text-muted">
            <p>
              Aether reads the Binance USDT tape with you. Ask for a scan, a name, or a
              size. Approvals fill the paper book at bid/ask.
            </p>
            <div className="flex flex-wrap gap-2">
              {["Scan the tape", "Risk check on the book", "What's working?"].map((q) => (
                <button
                  key={q}
                  type="button"
                  className="rounded-md border border-line bg-panel px-3 py-1.5 text-xs text-fg transition hover:border-primary/40"
                  onClick={() => void askAgent(q)}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {chat.map((turn) => (
          <div key={turn.id} className="space-y-2">
            <div
              className={
                turn.role === "user"
                  ? "ml-6 rounded-md border border-line bg-panel px-3 py-2 text-sm"
                  : "mr-4 rounded-md border border-line bg-card px-3 py-2 text-sm"
              }
            >
              <p className="mb-1 text-[10px] uppercase tracking-wider text-subtle">
                {turn.role === "user" ? "You" : "Aether"}
                {turn.stance ? ` · ${turn.stance}` : ""}
              </p>
              <p className="whitespace-pre-wrap leading-relaxed text-fg/95">{turn.text}</p>
            </div>
            {turn.proposals?.map((p) => (
              <div
                key={p.id}
                className="rounded-md border border-line bg-bg px-3 py-2 text-sm"
              >
                <div className="flex items-center justify-between gap-2">
                  <p className="font-medium">
                    <span className={p.action === "buy" ? "text-up" : "text-down"}>
                      {p.action.toUpperCase()}
                    </span>{" "}
                    {formatQty(p.qty)} {getPair(p.symbol).base}
                  </p>
                  <span className="tabular text-xs text-muted">
                    {Math.round(p.confidence * 100)}%
                  </span>
                </div>
                <p className="mt-1 text-xs text-muted">{p.rationale}</p>
                {p.status === "pending" ? (
                  <div className="mt-2 flex gap-2">
                    <button
                      type="button"
                      className="rounded-sm bg-primary px-3 py-1 text-xs font-medium text-primary-fg"
                      onClick={() => {
                        const res = approveProposal(turn.id, p.id);
                        flash(res.ok ? "Proposal filled (paper)." : res.error);
                      }}
                    >
                      Approve
                    </button>
                    <button
                      type="button"
                      className="rounded-sm border border-line px-3 py-1 text-xs text-muted"
                      onClick={() => dismissProposal(turn.id, p.id)}
                    >
                      Pass
                    </button>
                  </div>
                ) : (
                  <p className="mt-1 text-[10px] uppercase tracking-wider text-subtle">
                    {p.status}
                  </p>
                )}
              </div>
            ))}
          </div>
        ))}
        {agentBusy && (
          <p className="text-xs text-muted">Reading the tape…</p>
        )}
      </div>

      <form
        className="border-t border-line p-3"
        onSubmit={(e) => {
          e.preventDefault();
          void askAgent(prompt);
        }}
      >
        <div className="flex gap-2">
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask the desk…"
            className="min-w-0 flex-1 rounded-md border border-line bg-bg px-3 py-2 text-sm outline-none ring-ring focus:ring-1"
            disabled={agentBusy}
          />
          <button
            type="submit"
            disabled={agentBusy || !prompt.trim()}
            className="rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-fg disabled:opacity-40"
          >
            Send
          </button>
        </div>
      </form>
    </div>
  );

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="flex flex-wrap items-center gap-3 border-b border-line px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="text-lg font-semibold tracking-tight">Aether</span>
          <span className="rounded-sm border border-line px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-muted">
            Paper
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted">
          <span className={tapeStatus === "live" ? "live-dot" : "size-1.5 rounded-full bg-subtle"} />
          <span>BINANCE SPOT · USDT</span>
          {tapeError && <span className="text-down">{tapeError}</span>}
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-4 text-sm">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-subtle">Equity</p>
            <p className="tabular font-medium">{formatUsd(mark)}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-subtle">Day P&amp;L</p>
            <p className={`tabular font-medium ${signedClass(dayPnl)}`}>
              {formatUsd(dayPnl)} ({formatPct(dayPct)})
            </p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-subtle">Cash</p>
            <p className="tabular font-medium">{formatUsd(book.cash)}</p>
          </div>
          <div className="tabular text-xs text-muted">{now} ET</div>
          <button
            type="button"
            className="rounded-sm border border-line px-2 py-1 text-xs text-muted hover:text-fg"
            onClick={() => {
              if (confirm("Reset paper book to 100,000 USDT?")) resetBook();
            }}
          >
            Reset
          </button>
          <button
            type="button"
            className="rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-fg lg:hidden"
            onClick={() => setAgentOpen(true)}
          >
            Agent
          </button>
        </div>
      </header>

      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[240px_1fr_320px]">
        {/* Watchlist */}
        <aside className="desk-scroll max-h-[40vh] overflow-y-auto border-b border-line lg:max-h-none lg:border-b-0 lg:border-r">
          <div className="sticky top-0 z-10 border-b border-line bg-bg px-3 py-2 text-[10px] uppercase tracking-wider text-subtle">
            Watchlist
          </div>
          <ul>
            {UNIVERSE.map((p) => {
              const t = tickers[p.symbol];
              const active = selected === p.symbol;
              const spark = sparks[p.symbol] ?? [];
              return (
                <li key={p.symbol}>
                  <button
                    type="button"
                    onClick={() => select(p.symbol)}
                    className={`flex w-full items-center gap-2 border-l-2 px-3 py-2.5 text-left transition ${
                      active
                        ? "border-primary bg-panel"
                        : "border-transparent hover:bg-panel/60"
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">{p.base}</p>
                      <p className="truncate text-[11px] text-subtle">{p.name}</p>
                    </div>
                    {spark.length > 1 && (
                      <Spark values={spark} up={(t?.changePct ?? 0) >= 0} />
                    )}
                    <div className="text-right">
                      <p className="tabular text-sm">{formatPx(t?.last ?? 0)}</p>
                      <p className={`tabular text-[11px] ${signedClass(t?.changePct ?? 0)}`}>
                        {formatPct(t?.changePct ?? 0)}
                      </p>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </aside>

        {/* Chart + ticket + book */}
        <main className="flex min-h-0 flex-col border-b border-line lg:border-b-0 lg:border-r">
          <div className="flex flex-wrap items-end justify-between gap-3 border-b border-line px-4 py-3">
            <div>
              <p className="text-xs text-muted">
                {pair.name} · {pair.symbol}
              </p>
              <p className="tabular text-2xl font-semibold tracking-tight">
                {formatPx(ticker?.last ?? 0)}
              </p>
              <p className={`tabular text-sm ${signedClass(ticker?.changePct ?? 0)}`}>
                {formatPx(ticker?.change ?? 0)} ({formatPct(ticker?.changePct ?? 0)})
              </p>
            </div>
            <div className="flex flex-wrap gap-1">
              {INTERVALS.map((i) => (
                <button
                  key={i.id}
                  type="button"
                  onClick={() => setInterval(i.id as Interval)}
                  className={`rounded-sm px-2.5 py-1 text-xs ${
                    interval === i.id
                      ? "bg-primary text-primary-fg"
                      : "border border-line text-muted hover:text-fg"
                  }`}
                >
                  {i.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid min-h-[240px] flex-1 grid-cols-1 md:grid-cols-[1fr_160px]">
            <div className="relative h-[240px] md:h-auto">
              {marketLoading && !candles.length && (
                <p className="absolute inset-0 flex items-center justify-center text-xs text-muted">
                  Loading chart…
                </p>
              )}
              {chartData.length > 0 && (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 12, right: 12, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="fillPx" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={stroke} stopOpacity={0.28} />
                        <stop offset="100%" stopColor={stroke} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <YAxis
                      domain={["auto", "auto"]}
                      width={56}
                      tick={{ fill: "var(--color-subtle)", fontSize: 10 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        background: "var(--color-card)",
                        border: "1px solid var(--color-line)",
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                      labelFormatter={() => ""}
                      formatter={(v: number) => [formatPx(v), "Last"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="c"
                      stroke={stroke}
                      fill="url(#fillPx)"
                      strokeWidth={1.5}
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>

            <div className="desk-scroll border-t border-line px-2 py-2 text-[11px] md:border-l md:border-t-0">
              <p className="mb-1 px-1 text-[10px] uppercase tracking-wider text-subtle">
                Order book
              </p>
              <div className="space-y-0.5">
                {[...asks].reverse().map((l) => (
                  <BookRow key={`a-${l.price}`} level={l} side="ask" max={maxBookQty} />
                ))}
                <div className="my-1 border-y border-line py-1 text-center tabular text-xs font-medium">
                  {formatPx(ticker?.last ?? 0)}
                </div>
                {bids.map((l) => (
                  <BookRow key={`b-${l.price}`} level={l} side="bid" max={maxBookQty} />
                ))}
              </div>
              <p className="mb-1 mt-3 px-1 text-[10px] uppercase tracking-wider text-subtle">
                Last prints
              </p>
              <ul className="space-y-0.5">
                {trades.slice(0, 8).map((t) => (
                  <li key={t.id} className="flex justify-between px-1 tabular">
                    <span className={t.sell ? "text-down" : "text-up"}>{formatPx(t.price)}</span>
                    <span className="text-muted">{formatQty(t.qty)}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 border-t border-line p-3">
            <input
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              placeholder={`Size (${pair.base})`}
              className="w-36 rounded-md border border-line bg-bg px-3 py-2 text-sm outline-none ring-ring focus:ring-1"
            />
            <button
              type="button"
              onClick={() => onTrade("buy")}
              className="rounded-md bg-up px-4 py-2 text-sm font-medium text-bg"
            >
              Buy
            </button>
            <button
              type="button"
              onClick={() => onTrade("sell")}
              className="rounded-md bg-down px-4 py-2 text-sm font-medium text-fg"
            >
              Sell
            </button>
            <p className="text-xs text-muted">
              Paper fill at {ticker ? (ticker.ask ? "ask / bid" : "last") : "—"} · vol{" "}
              {formatCompact(ticker?.quoteVolume ?? 0)}
            </p>
          </div>
        </main>

        {/* Agent desktop */}
        <aside className="hidden min-h-0 lg:flex lg:flex-col">{agentPanel}</aside>
      </div>

      {/* Positions + blotter */}
      <section className="grid max-h-[28vh] grid-cols-1 border-t border-line md:grid-cols-2">
        <div className="desk-scroll overflow-y-auto border-b border-line md:border-b-0 md:border-r">
          <div className="sticky top-0 border-b border-line bg-bg px-4 py-2 text-[10px] uppercase tracking-wider text-subtle">
            Positions
          </div>
          {book.positions.length === 0 ? (
            <p className="px-4 py-3 text-sm text-muted">No open positions.</p>
          ) : (
            <table className="w-full text-left text-sm">
              <thead className="text-[10px] uppercase tracking-wider text-subtle">
                <tr>
                  <th className="px-4 py-2 font-medium">Pair</th>
                  <th className="px-2 py-2 font-medium">Qty</th>
                  <th className="px-2 py-2 font-medium">Avg</th>
                  <th className="px-2 py-2 font-medium">Last</th>
                  <th className="px-4 py-2 font-medium">P&amp;L</th>
                </tr>
              </thead>
              <tbody>
                {book.positions.map((p) => {
                  const last = tickers[p.symbol]?.last ?? p.avgCost;
                  const pnl = (last - p.avgCost) * p.qty;
                  return (
                    <tr
                      key={p.symbol}
                      className="cursor-pointer border-t border-line/60 hover:bg-panel/50"
                      onClick={() => select(p.symbol)}
                    >
                      <td className="px-4 py-2 font-medium">{getPair(p.symbol).base}</td>
                      <td className="tabular px-2 py-2">{formatQty(p.qty)}</td>
                      <td className="tabular px-2 py-2">{formatPx(p.avgCost)}</td>
                      <td className="tabular px-2 py-2">{formatPx(last)}</td>
                      <td className={`tabular px-4 py-2 ${signedClass(pnl)}`}>
                        {formatUsd(pnl)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        <div className="desk-scroll overflow-y-auto">
          <div className="sticky top-0 border-b border-line bg-bg px-4 py-2 text-[10px] uppercase tracking-wider text-subtle">
            Blotter
          </div>
          {book.fills.length === 0 ? (
            <p className="px-4 py-3 text-sm text-muted">No fills yet.</p>
          ) : (
            <ul className="divide-y divide-line/60 text-sm">
              {book.fills.slice(0, 40).map((f) => (
                <li key={f.id} className="flex items-center gap-3 px-4 py-2">
                  <span className={f.side === "buy" ? "text-up" : "text-down"}>
                    {f.side.toUpperCase()}
                  </span>
                  <span className="font-medium">{getPair(f.symbol).base}</span>
                  <span className="tabular text-muted">
                    {formatQty(f.qty)} @ {formatPx(f.price)}
                  </span>
                  <span className="ml-auto tabular text-xs text-subtle">
                    {new Date(f.ts).toLocaleTimeString()}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <footer className="border-t border-line px-4 py-2 text-[11px] text-subtle">
        Paper trading only. Not financial advice. Quotes via Binance public market data
        (may be delayed). Live account trading is not enabled in this build.
      </footer>

      {agentOpen && (
        <div className="fixed inset-0 z-50 flex flex-col bg-bg lg:hidden">
          {agentPanel}
        </div>
      )}

      {toast && (
        <div className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-md border border-line bg-card px-4 py-2 text-sm shadow-lg">
          {toast}
        </div>
      )}
    </div>
  );
}

function Spark({ values, up }: { values: number[]; up: boolean }) {
  if (values.length < 2) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const w = 48;
  const h = 20;
  const d = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * w;
      const y = h - ((v - min) / span) * h;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-hidden className="shrink-0">
      <path
        d={d}
        fill="none"
        stroke={up ? "var(--color-up)" : "var(--color-down)"}
        strokeWidth="1.25"
      />
    </svg>
  );
}

function BookRow({
  level,
  side,
  max,
}: {
  level: { price: number; qty: number };
  side: "bid" | "ask";
  max: number;
}) {
  const pct = Math.min(100, (level.qty / max) * 100);
  const color = side === "bid" ? "var(--color-up)" : "var(--color-down)";
  return (
    <div className="relative flex justify-between px-1 py-0.5 tabular">
      <span
        className="absolute inset-y-0 right-0 opacity-15"
        style={{ width: `${pct}%`, background: color }}
      />
      <span className={side === "bid" ? "text-up" : "text-down"}>{formatPx(level.price)}</span>
      <span className="relative text-muted">{formatQty(level.qty)}</span>
    </div>
  );
}
